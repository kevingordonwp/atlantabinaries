/*
 * Main.java
 *
 * Created on 26 November 2007, 20:43
 *
 * This is the main class for running KevTris - a Tetris clone written as a java
 * applet.
 */
package kevtris;

import java.awt.*;

/**
 *
 * @author Kevin Gordon
 */
public class Main {
    
    /** Creates a new instance of Main */
    public Main() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("This is KevTris, welcome");
    }
    
}
